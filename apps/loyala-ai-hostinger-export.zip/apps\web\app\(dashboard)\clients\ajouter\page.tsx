import { requireAuth } from '@/lib/auth/guard';
import { WelcomeBanner } from '@/components/clients/welcome-banner';
import { NewClientForm } from '../new/new-client-form';

export const dynamic = 'force-dynamic';

export default async function AjouterClientPage({
  searchParams,
}: {
  searchParams: Promise<{ welcome?: string }>;
}) {
  await requireAuth();
  const { welcome } = await searchParams;
  const showWelcome = welcome === '1';

  return (
    <div className="mx-auto max-w-lg space-y-6 animate-fade-in">
      {showWelcome && <WelcomeBanner />}
      <div>
        <h2 className="text-2xl font-semibold tracking-tight">Nouveau client</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {showWelcome
            ? 'Commencez par un client fidèle — vous pourrez le relancer tout de suite.'
            : 'Ajoutez un client à votre CRM'}
        </p>
      </div>
      <NewClientForm />
    </div>
  );
}
