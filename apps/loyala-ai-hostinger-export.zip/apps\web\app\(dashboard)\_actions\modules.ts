'use server';

import { revalidatePath } from 'next/cache';
import type { OrgRole } from '@loyala/core-iam';
import { requireAuth } from '@/lib/auth/guard';
import { getSession } from '@/lib/auth/session';
import { createClient } from '@/lib/supabase/server';
import {
  listClients,
  syncClientSegments,
  getOrganization,
  persistCampaignPlans,
  type CampaignPlanPayload,
} from '@loyala/domain-crm';
import { notifyCampaignReadyByEmail } from '@loyala/integrations';
import { proxyToWorker } from '@/lib/worker/client';

const CAMPAIGN_WRITE_ROLES: OrgRole[] = ['org_owner', 'org_admin', 'org_manager', 'org_staff'];

function canRunCampaigns(role: OrgRole): boolean {
  return CAMPAIGN_WRITE_ROLES.includes(role);
}

export type ModuleActionState = { error?: string; success?: string };

async function generateLoyaltyCampaign(
  ctx: Awaited<ReturnType<typeof requireAuth>>,
  campaignType: 'inactive' | 'birthday',
  filterClients: (clients: Awaited<ReturnType<typeof listClients>>) => Awaited<ReturnType<typeof listClients>>
): Promise<ModuleActionState> {
  const supabase = await createClient();

  const org = await getOrganization(supabase, ctx.organizationId);
  let clients = await listClients(supabase, ctx.organizationId);
  await syncClientSegments(supabase, ctx.organizationId, clients);
  clients = await listClients(supabase, ctx.organizationId);

  const targets = filterClients(clients).filter((c) => c.opt_in_whatsapp && c.phone);
  if (targets.length === 0) {
    return {
      error:
        campaignType === 'birthday'
          ? 'Aucun anniversaire aujourd\'hui avec opt-in WhatsApp'
          : 'Aucun client inactif à relancer',
    };
  }

  const workerPath = campaignType === 'birthday' ? 'campaigns/birthday' : 'campaigns/loyalty';
  const workerBody =
    campaignType === 'birthday'
      ? {
          clients: targets.map((c) => ({
            clientId: c.id,
            fullName: c.full_name,
            birthday: c.date_of_birth ?? new Date().toISOString(),
          })),
          restaurantName: org?.name ?? 'Restaurant',
        }
      : {
          clients: targets.map((c) => ({
            clientId: c.id,
            fullName: c.full_name,
            loyaltyPoints: c.loyalty_points,
            lastVisit: c.last_visit_at ?? new Date(0).toISOString(),
          })),
        };

  const workerResult = await proxyToWorker<{ campaigns?: CampaignPlanPayload[] }>(workerPath, {
    method: 'POST',
    organizationId: ctx.organizationId,
    body: workerBody,
  });

  if (!workerResult.ok) {
    return { error: workerResult.error ?? 'Worker IA indisponible' };
  }

  const plans = workerResult.data.campaigns ?? [];
  const campaignName =
    campaignType === 'birthday'
      ? `Anniversaires — ${new Date().toLocaleDateString('fr-FR')}`
      : `Relance inactifs — ${new Date().toLocaleDateString('fr-FR')}`;

  const { sendCount } = await persistCampaignPlans(supabase, {
    organizationId: ctx.organizationId,
    restaurantName: org?.name ?? 'Restaurant',
    campaignType,
    campaignName,
    plans,
    clients: targets.map((c) => ({
      id: c.id,
      full_name: c.full_name,
      phone: c.phone,
      opt_in_whatsapp: c.opt_in_whatsapp,
    })),
    createdBy: ctx.userId,
    source: 'manual',
  });

  const session = await getSession();
  if (session?.email) {
    try {
      await notifyCampaignReadyByEmail({
        to: session.email,
        restaurantName: org?.name ?? 'Restaurant',
        count: sendCount,
        campaignType: campaignType === 'birthday' ? 'anniversaire' : 'inactifs',
      });
    } catch {
      // Email is optional — in-app notification already created
    }
  }

  if (sendCount === 0) {
    return {
      error:
        plans.length === 0
          ? 'Le worker IA n\'a généré aucun message — vérifiez la configuration worker'
          : 'Aucune relance enregistrée (clients sans opt-in WhatsApp ou numéro manquant)',
    };
  }

  revalidatePath('/campaigns');
  revalidatePath('/relances');
  revalidatePath('/notifications');
  return {
    success: `${sendCount} relance(s) générée(s) — consultez Relances pour envoyer`,
  };
}

export async function generateInactiveCampaignAction(
  _prev: ModuleActionState,
  _formData: FormData
): Promise<ModuleActionState> {
  const ctx = await requireAuth();
  if (!canRunCampaigns(ctx.role)) {
    return { error: 'Permission insuffisante — rôle lecture seule (org_viewer)' };
  }
  const supabase = await createClient();

  try {
    let clients = await listClients(supabase, ctx.organizationId);
    await syncClientSegments(supabase, ctx.organizationId, clients);
    clients = await listClients(supabase, ctx.organizationId);

    const { isClientInactive } = await import('@loyala/domain-crm');
    return await generateLoyaltyCampaign(ctx, 'inactive', (list) =>
      list.filter((c) => isClientInactive(c))
    );
  } catch (e) {
    return { error: e instanceof Error ? e.message : 'Erreur génération campagne' };
  }
}

export async function generateBirthdayCampaignAction(
  _prev: ModuleActionState,
  _formData: FormData
): Promise<ModuleActionState> {
  const ctx = await requireAuth();
  if (!canRunCampaigns(ctx.role)) {
    return { error: 'Permission insuffisante — rôle lecture seule (org_viewer)' };
  }

  try {
    const today = new Date();
    const month = today.getMonth() + 1;
    const day = today.getDate();

    return await generateLoyaltyCampaign(ctx, 'birthday', (list) =>
      list.filter((c) => {
        if (!c.date_of_birth) return false;
        const dob = new Date(c.date_of_birth);
        return dob.getMonth() + 1 === month && dob.getDate() === day;
      })
    );
  } catch (e) {
    return { error: e instanceof Error ? e.message : 'Erreur génération anniversaires' };
  }
}

export async function markRelanceSentAction(sendId: string): Promise<ModuleActionState> {
  const ctx = await requireAuth();
  const supabase = await createClient();
  const { markCampaignSendSent } = await import('@loyala/domain-crm');

  try {
    await markCampaignSendSent(supabase, ctx.organizationId, sendId);
    revalidatePath('/relances');
    revalidatePath('/dashboard');
    return { success: 'Relance marquée comme envoyée' };
  } catch (e) {
    return { error: e instanceof Error ? e.message : 'Erreur' };
  }
}
